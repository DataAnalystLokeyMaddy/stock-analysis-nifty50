# scripts/streamlit_app.py

import streamlit as st
import pandas as pd
import mysql.connector
import matplotlib.pyplot as plt

# -----------------------------
# Database connection (XAMPP)
# -----------------------------
def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",              # XAMPP default
        database="stocks_2024"
    )

# -----------------------------
# Load full table
# -----------------------------
@st.cache_data
def load_data():
    conn = get_connection()
    query = """
        SELECT
            Ticker,
            Date,
            Open,
            High,
            Low,
            Close,
            Volume,
            Month,
            Daily_Return,
            Cumulative_Return,
            Yearly_Return
        FROM stocks_cleaned
        ORDER BY Date
    """
    df = pd.read_sql(query, conn)
    conn.close()
    return df

# -----------------------------
# Main app
# -----------------------------
def main():
    st.set_page_config(page_title="Stock Analysis Dashboard", layout="wide")
    st.title("📈 Stock Analysis Dashboard")

    df = load_data()

    if df.empty:
        st.error("No data found in stocks_cleaned table.")
        return

    # Sidebar filter
    st.sidebar.header("Filters")
    ticker_list = sorted(df["Ticker"].dropna().unique())
    selected_ticker = st.sidebar.selectbox("Select Ticker", ticker_list)

    stock_df = df[df["Ticker"] == selected_ticker].copy()
    stock_df["Date"] = pd.to_datetime(stock_df["Date"])
    stock_df = stock_df.sort_values("Date")

    # -----------------------------
    # KPIs
    # -----------------------------
    first_price = stock_df["Close"].iloc[0]
    last_price = stock_df["Close"].iloc[-1]
    yearly_return = ((last_price - first_price) / first_price) * 100

    col1, col2, col3 = st.columns(3)
    col1.metric("First Close Price", f"{first_price:.2f}")
    col2.metric("Last Close Price", f"{last_price:.2f}")
    col3.metric("Yearly Return (%)", f"{yearly_return:.2f}")

    # -----------------------------
    # Price trend chart
    # -----------------------------
    st.subheader(f"{selected_ticker} – Close Price Trend")

    fig, ax = plt.subplots()
    ax.plot(stock_df["Date"], stock_df["Close"])
    ax.set_xlabel("Date")
    ax.set_ylabel("Close Price")
    ax.grid(True)

    st.pyplot(fig)

    # -----------------------------
    # Daily return chart
    # -----------------------------
    st.subheader("Daily Returns")

    fig2, ax2 = plt.subplots()
    ax2.bar(stock_df["Date"], stock_df["Daily_Return"])
    ax2.set_xlabel("Date")
    ax2.set_ylabel("Daily Return")
    ax2.grid(True)

    st.pyplot(fig2)

    # -----------------------------
    # Green vs Red stocks (overall)
    # -----------------------------
    st.subheader("Market Overview (Green vs Red Stocks)")

    conn = get_connection()
    query_green_red = """
        SELECT
            SUM(CASE WHEN Yearly_Return > 0 THEN 1 ELSE 0 END) AS Green,
            SUM(CASE WHEN Yearly_Return < 0 THEN 1 ELSE 0 END) AS Red
        FROM (
            SELECT
                Ticker,
                ROUND(((MAX(Close) - MIN(Close)) / MIN(Close)) * 100, 2) AS Yearly_Return
            FROM stocks_cleaned
            GROUP BY Ticker
        ) t
    """
    green_red_df = pd.read_sql(query_green_red, conn)
    conn.close()

    st.dataframe(green_red_df)

# -----------------------------
# Run app
# -----------------------------
if __name__ == "__main__":
    main()
